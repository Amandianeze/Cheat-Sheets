#!/bin/bash
# install-api-explorer.sh
# Installs the API Explorer subagent for Claude Code
# Usage: bash install-api-explorer.sh [--global | --project]

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AGENT_FILE="$SCRIPT_DIR/api-explorer.md"

if [ ! -f "$AGENT_FILE" ]; then
  echo "❌ Error: api-explorer.md not found in $SCRIPT_DIR"
  exit 1
fi

MODE="${1:---global}"

case "$MODE" in
  --global|-g)
    TARGET_DIR="$HOME/.claude/agents"
    SCOPE="user-level (available in all projects)"
    ;;
  --project|-p)
    TARGET_DIR=".claude/agents"
    SCOPE="project-level (available in current project only)"
    ;;
  *)
    echo "Usage: bash install-api-explorer.sh [--global | --project]"
    echo "  --global, -g   Install for all projects (~/.claude/agents/)"
    echo "  --project, -p  Install for current project (.claude/agents/)"
    exit 1
    ;;
esac

echo "⚡ Installing API Explorer subagent..."
echo "   Scope: $SCOPE"
echo "   Target: $TARGET_DIR/api-explorer.md"
echo ""

mkdir -p "$TARGET_DIR"
cp "$AGENT_FILE" "$TARGET_DIR/api-explorer.md"

echo "✅ API Explorer subagent installed successfully!"
echo ""
echo "📋 Quick start:"
echo "   1. Open Claude Code"
echo "   2. Run: /agents  (to verify it appears)"
echo "   3. Try: 'Use the api-explorer agent to fetch https://jsonplaceholder.typicode.com/posts'"
echo ""
echo "🔧 To customize, edit: $TARGET_DIR/api-explorer.md"

# Verify jq is available (used by the agent for JSON analysis)
if ! command -v jq &> /dev/null; then
  echo ""
  echo "⚠️  Recommended: Install jq for better JSON analysis"
  echo "   macOS:  brew install jq"
  echo "   Ubuntu: sudo apt install jq"
  echo "   Other:  https://jqlang.github.io/jq/download/"
fi
