# ⚡ API Explorer — Claude Code Subagent

A specialized Claude Code subagent that connects to **any REST API**, fetches data, and delivers a comprehensive analysis of the response — structure, field types, data quality, and pipeline recommendations.

## What It Does

When you point it at an API endpoint, the agent:

1. **Fetches** the data with proper headers, error handling, and timing
2. **Profiles** every field — types, nullability, cardinality, patterns
3. **Analyzes** the data for quality issues, anomalies, and relationships
4. **Recommends** warehouse schemas, partition strategies, and load patterns
5. **Generates** ready-to-use Python/SQL code for your pipeline

## Install

### Option A: Global (all projects)

```bash
bash install-api-explorer.sh --global
```

### Option B: Project-level

```bash
bash install-api-explorer.sh --project
```

### Option C: Manual

```bash
# Global
mkdir -p ~/.claude/agents && cp api-explorer.md ~/.claude/agents/

# Project
mkdir -p .claude/agents && cp api-explorer.md .claude/agents/
```

## Usage Examples

Once installed, Claude Code will **automatically delegate** API exploration tasks to this agent. You can also invoke it explicitly:

### Basic API exploration

```
> Use the api-explorer agent to fetch and analyze https://api.open-meteo.com/v1/forecast?latitude=40.71&longitude=-74.01&current_weather=true
```

### Explore with authentication

```
> Use api-explorer to connect to https://api.github.com/user/repos — I'll need to pass my token as a Bearer header
```

### Compare endpoints

```
> Use api-explorer to compare the schema of /users and /posts from jsonplaceholder.typicode.com
```

### Generate pipeline code

```
> Use api-explorer to fetch https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd and write a Python script to load this into a Polars DataFrame
```

### Debug a failing API

```
> Use api-explorer to diagnose why my request to https://api.example.com/v2/data keeps returning 403
```

## What You Get

For every API call, the agent produces:

| Section | Contents |
|---------|----------|
| **Data Shape** | Top-level type, record count, pagination info |
| **Field Breakdown** | Name, type, nullable, description, example value |
| **Key Insights** | Patterns, anomalies, data quality flags |
| **Pipeline Recs** | SQL schema, primary keys, partitioning, incremental strategy |
| **Next Steps** | Related endpoints, suggested filters, deeper exploration |

## Configuration

The agent uses these tools by default:

| Tool | Purpose |
|------|---------|
| `Bash` | Run curl, jq, python for fetching and analysis |
| `Read` | Read saved response files and scripts |
| `Write` | Save analysis scripts and generated code |
| `Edit` | Modify generated pipeline code |
| `Glob` | Find related files in the project |
| `Grep` | Search for existing API integrations in code |

**Model**: Sonnet (good balance of speed and capability for data analysis)

To change the model or tools, edit the YAML frontmatter in `api-explorer.md`.

## Dependencies

The agent works best with these tools available in your environment:

- **jq** — JSON processing (recommended, `brew install jq`)
- **python3** + **pandas** — Deeper data profiling (optional)
- **curl** — HTTP requests (pre-installed on most systems)

## Customization

Edit `api-explorer.md` to:

- Add your organization's common API base URLs
- Include default authentication patterns
- Customize the output format
- Add domain-specific analysis rules (e.g., healthcare data validation)
- Add MCP tools for connecting to your internal services

## Tips

- The agent automatically saves responses to `/tmp/api_response.json` so you can reference them later in the session
- For APIs requiring auth, set environment variables (`export API_KEY=xxx`) before starting Claude Code
- The agent respects rate limits — it will back off and retry when throttled
- Ask follow-up questions like "write the SQL schema" or "paginate through all results" after the initial analysis
