# Spec Kit + Claude Code Parallel Execution Configuration

A complete configuration package for integrating GitHub Spec Kit with Claude Code's parallel execution capabilities through custom subagents and an optimized CLAUDE.md.

## Quick Start

### 1. Copy to Your Project

```bash
# Clone or download this configuration
git clone [this-repo] speckit-config

# Copy to your Spec Kit project
cp -r speckit-config/.claude/agents/ /path/to/your/project/.claude/agents/
cp speckit-config/CLAUDE.md /path/to/your/project/CLAUDE.md
```

### 2. Customize CLAUDE.md

Edit the `CLAUDE.md` file and update:
- Project name and description
- Tech stack details
- Build commands
- Environment requirements

### 3. Initialize Spec Kit (if not already done)

```bash
cd your-project
uvx --from git+https://github.com/github/spec-kit.git specify init --here
```

### 4. Verify Setup

Start Claude Code and run:
```
/agents
```

You should see the custom agents listed:
- spec-validator
- spec-researcher
- task-implementer
- integration-coordinator
- test-validator

## Directory Structure

```
your-project/
├── .claude/
│   ├── agents/                    # ← Custom subagents
│   │   ├── spec-validator.md
│   │   ├── spec-researcher.md
│   │   ├── task-implementer.md
│   │   ├── integration-coordinator.md
│   │   └── test-validator.md
│   └── commands/                  # ← Spec Kit commands (from specify init)
│       ├── speckit.specify.md
│       ├── speckit.plan.md
│       ├── speckit.tasks.md
│       └── speckit.implement.md
├── .specify/                      # ← Spec Kit artifacts
│   ├── memory/
│   ├── specs/
│   ├── templates/
│   └── scripts/
├── CLAUDE.md                      # ← Parallel execution config
└── [your source code]
```

## Subagent Overview

| Agent | Purpose | When Invoked |
|-------|---------|--------------|
| **spec-validator** | Validates specifications for completeness, consistency, clarity | Before `/speckit.plan`, during `/speckit.analyze` |
| **spec-researcher** | Parallel technical research on specific questions | During `/speckit.plan` for tech decisions |
| **task-implementer** | Implements single tasks from tasks.md | During `/speckit.implement` for [P] tasks |
| **integration-coordinator** | Validates parallel work integrates correctly | After [P] batch completion |
| **test-validator** | Verifies TDD compliance (tests fail before implementation) | Before implementation tasks in TDD mode |

## Usage Examples

### Automatic Parallel Execution

When you run `/speckit.implement` and tasks.md contains [P] markers:

```
Phase 2: Core Implementation
├── [P] Task 2.1: Create UserService.ts
├── [P] Task 2.2: Create UserController.ts
├── [P] Task 2.3: Create User.types.ts
└── [S] Task 2.4: Wire up routes
```

Claude will automatically:
1. Spawn 3 parallel `@task-implementer` agents for [P] tasks
2. Wait for completion
3. Run `@integration-coordinator` to validate
4. Execute [S] sequential task

### Manual Parallel Research

During planning, trigger parallel research:

```
"I need to decide between Prisma and Drizzle ORM. 
Spawn parallel research tasks to compare:
- Performance benchmarks
- TypeScript support quality
- Migration handling
- Community support"
```

Claude will spawn 4 `@spec-researcher` agents simultaneously.

### Explicit Agent Invocation

```
"Use @spec-validator to check the current specification"
"Run @integration-coordinator on Tasks 2.1 through 2.5"
"Use @test-validator to verify tests are failing before implementation"
```

## Configuration Reference

### CLAUDE.md Key Sections

| Section | Purpose |
|---------|---------|
| **Project Context** | Basic project info, customize this |
| **Spec Kit Integration** | File locations and loading priority |
| **Parallel Execution System** | Task tool delegation rules |
| **Phase-Specific Rules** | Parallelization level per Spec Kit phase |
| **Context Optimization** | Token efficiency patterns |
| **Conflict Prevention** | Safe parallel boundaries |
| **Subagent Reference** | Quick lookup for all agents |

### Parallelization Levels

| Phase | Level | Typical Pattern |
|-------|-------|-----------------|
| `/speckit.specify` | LOW | Sequential dialogue, occasional research |
| `/speckit.plan` | MEDIUM-HIGH | Parallel research for tech decisions |
| `/speckit.tasks` | LOW | Task generation is sequential |
| `/speckit.implement` | MAXIMUM | Parallel [P] task execution |

### Task Tool Limits

- **Max concurrent Tasks**: 10 (Claude Code limit)
- **Recommended default**: 7 concurrent Tasks
- **Overhead per Task**: ~20k tokens
- **Batch behavior**: Tasks queue and pull as slots free

## Customization

### Adding New Subagents

Create a new `.md` file in `.claude/agents/`:

```markdown
---
name: your-agent-name
description: When to use this agent (Claude reads this to decide)
allowed-tools: Read, Write, Edit, Bash, Grep, Glob
model: sonnet  # or haiku for faster/cheaper
---

# Agent Title

Your agent's system prompt goes here...
```

### Modifying Parallel Behavior

Edit CLAUDE.md's "Immediate Parallel Execution Triggers" table to add/remove automatic parallelization patterns.

### Adjusting Parallelism Level

In CLAUDE.md, modify the "Parallelism Configuration" table:

```markdown
| Default parallelism | 7 | Change to desired number |
```

## Troubleshooting

### Agents Not Appearing

```bash
# Verify file locations
ls -la .claude/agents/

# Check file permissions
chmod 644 .claude/agents/*.md

# Restart Claude Code session
```

### Parallel Tasks Not Spawning

1. Check CLAUDE.md is in project root
2. Verify tasks.md has [P] markers
3. Try explicit command: "Execute [P] tasks using parallel agents"

### Context Depletion

1. Run `/compact` to summarize state
2. Commit progress: `git add -A && git commit -m "WIP"`
3. Start new session, reference tasks.md for continuity

### Integration Failures After Parallel Batch

1. Run `@integration-coordinator` explicitly
2. Check for file conflicts in report
3. Resolve conflicts manually or re-run affected tasks

## Best Practices

1. **Trust the orchestrator pattern**: Let Claude delegate, don't micromanage
2. **Keep [P] tasks truly independent**: No shared file modifications
3. **Use [S] for coordination points**: Sequential tasks after parallel batches
4. **Run integration checks**: Always validate after parallel execution
5. **Commit frequently**: Parallel execution can make rollback complex

## Contributing

Found improvements? Open an issue or PR with:
- New subagent configurations
- CLAUDE.md optimizations
- Workflow enhancements
- Documentation improvements

## License

MIT - Use freely in your projects.

---

*Compatible with Spec Kit v0.0.39+ and Claude Code v2.1.x+*
