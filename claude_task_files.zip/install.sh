#!/bin/bash

# Spec Kit + Claude Code Parallel Execution Setup Script
# Installs custom subagents and CLAUDE.md configuration

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  Spec Kit + Claude Code Parallel Execution Setup${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# Determine script location
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Get target directory
if [ -z "$1" ]; then
    TARGET_DIR="$(pwd)"
else
    TARGET_DIR="$1"
fi

echo -e "📁 Target directory: ${YELLOW}${TARGET_DIR}${NC}"
echo ""

# Check if target exists
if [ ! -d "$TARGET_DIR" ]; then
    echo -e "${RED}Error: Target directory does not exist${NC}"
    exit 1
fi

# Create directories
echo -e "📂 Creating directories..."
mkdir -p "$TARGET_DIR/.claude/agents"
mkdir -p "$TARGET_DIR/.claude/commands"

# Copy agents
echo -e "🤖 Installing subagents..."
if [ -d "$SCRIPT_DIR/.claude/agents" ]; then
    cp "$SCRIPT_DIR/.claude/agents/"*.md "$TARGET_DIR/.claude/agents/"
    echo -e "   ✅ spec-validator.md"
    echo -e "   ✅ spec-researcher.md"
    echo -e "   ✅ task-implementer.md"
    echo -e "   ✅ integration-coordinator.md"
    echo -e "   ✅ test-validator.md"
else
    echo -e "${RED}   ❌ Agent files not found in source${NC}"
    exit 1
fi

# Copy commands
echo -e "⚡ Installing slash commands..."
if [ -d "$SCRIPT_DIR/.claude/commands" ]; then
    cp "$SCRIPT_DIR/.claude/commands/"*.md "$TARGET_DIR/.claude/commands/" 2>/dev/null || true
    echo -e "   ✅ research.md (parallel research command)"
fi

# Handle CLAUDE.md
echo ""
if [ -f "$TARGET_DIR/CLAUDE.md" ]; then
    echo -e "${YELLOW}⚠️  CLAUDE.md already exists in target${NC}"
    read -p "   Overwrite? (y/N): " -n 1 -r
    echo ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        cp "$SCRIPT_DIR/CLAUDE.md" "$TARGET_DIR/CLAUDE.md"
        echo -e "   ✅ CLAUDE.md overwritten"
    else
        cp "$SCRIPT_DIR/CLAUDE.md" "$TARGET_DIR/CLAUDE.md.speckit-parallel"
        echo -e "   📄 Saved as CLAUDE.md.speckit-parallel (merge manually)"
    fi
else
    cp "$SCRIPT_DIR/CLAUDE.md" "$TARGET_DIR/CLAUDE.md"
    echo -e "📝 Installing CLAUDE.md..."
    echo -e "   ✅ CLAUDE.md installed"
fi

# Check for Spec Kit
echo ""
if [ -d "$TARGET_DIR/.specify" ]; then
    echo -e "✅ Spec Kit detected (.specify directory exists)"
else
    echo -e "${YELLOW}⚠️  Spec Kit not initialized${NC}"
    echo -e "   Run: uvx --from git+https://github.com/github/spec-kit.git specify init --here"
fi

# Summary
echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  Installation Complete!${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "📋 Installed files:"
echo -e "   ${TARGET_DIR}/.claude/agents/"
echo -e "      ├── spec-validator.md"
echo -e "      ├── spec-researcher.md"
echo -e "      ├── task-implementer.md"
echo -e "      ├── integration-coordinator.md"
echo -e "      └── test-validator.md"
echo -e "   ${TARGET_DIR}/.claude/commands/"
echo -e "      └── research.md"
echo -e "   ${TARGET_DIR}/CLAUDE.md"
echo ""
echo -e "🚀 Next steps:"
echo -e "   1. Edit CLAUDE.md to customize for your project"
echo -e "   2. Start Claude Code in your project directory"
echo -e "   3. Run /agents to verify agents are loaded"
echo -e "   4. Try /research [topic] to test parallel research"
echo ""
