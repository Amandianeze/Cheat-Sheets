# CLAUDE.md

> **Configuration for Spec-Driven Development with Maximum Parallel Execution**
> 
> This file configures Claude Code to work optimally with GitHub Spec Kit,
> emphasizing aggressive parallelization through the Task tool and custom subagents.

---

## Project Context

<!-- CUSTOMIZE THIS SECTION FOR YOUR PROJECT -->
**Project Name**: [Your Project Name]
**Description**: [Brief project description]
**Tech Stack**: [e.g., TypeScript, React, Node.js, PostgreSQL]
**Repository**: [URL]

---

## Spec-Driven Development Configuration

### Spec Kit Integration

This project uses [GitHub Spec Kit](https://github.com/github/spec-kit) for specification-driven development. All development follows this artifact hierarchy:

```
.specify/
├── memory/
│   ├── constitution.md              # Project guardrails (READ FIRST - ALWAYS)
│   └── constitution_update_checklist.md
├── specs/
│   └── [feature-branch-name]/
│       ├── spec.md                  # Feature specification
│       ├── plan.md                  # Technical implementation plan
│       ├── tasks.md                 # Execution roadmap with [P] markers
│       ├── research.md              # Technical research findings
│       └── contracts/               # API specs, data models
├── templates/
│   ├── spec-template.md
│   ├── plan-template.md
│   └── tasks-template.md
└── scripts/
    └── [setup scripts]
```

### Context Loading Priority

When starting any task, load context in this order:

1. **CLAUDE.md** (this file) - Always in context
2. **constitution.md** - Project guardrails and constraints
3. **Current feature's spec.md** - What we're building
4. **Current feature's plan.md** - How we're building it
5. **Current feature's tasks.md** - Execution roadmap

### Active Feature Detection

```bash
# Auto-detect from git branch
FEATURE_BRANCH=$(git branch --show-current)
FEATURE_DIR=".specify/specs/${FEATURE_BRANCH}"

# Or use SPECKIT_FEATURE_DIR environment variable override
```

---

## Parallel Execution System

### CRITICAL: Task Tool Delegation Rules

**You are the ORCHESTRATOR.** Your primary role is to coordinate work, not execute it directly. Delegate aggressively using the Task tool to maximize parallelization and preserve main context.

### Parallelism Configuration

| Setting | Value | Notes |
|---------|-------|-------|
| Default parallelism | 7 | Concurrent Tasks to spawn |
| Maximum parallelism | 10 | Claude Code hard limit |
| Task overhead | ~20k tokens | Each Task spawns with context |
| Batch behavior | Queue-based | Tasks pull from queue as completed |

### Immediate Parallel Execution Triggers

When you encounter these patterns, spawn parallel Tasks **WITHOUT asking for confirmation**:

| Pattern | Action | Example |
|---------|--------|---------|
| `[P]` markers in tasks.md | One Task per [P] item | 5 [P] tasks → 5 parallel Tasks |
| "Research X, Y, and Z" | One Task per topic | 3 research topics → 3 Tasks |
| Multiple independent files | One Task per file/module | 4 files → 4 Tasks |
| "Implement US1, US2, US3" | One Task per user story | 3 stories → 3 Tasks |
| "Analyze/review/check [list]" | One Task per item | 6 items → 6 Tasks |

### Task Spawning Templates

#### For [P]-Marked Tasks in tasks.md
```
Parse tasks.md for current phase
Identify all [P]-marked tasks
For each [P] task:
  Task(
    prompt: "You are @task-implementer. Execute Task [ID]: [description]
             Files: [file list from task]
             Context: [relevant spec/plan sections]
             Report completion status using standard template.",
    subagent_type: "task-implementer"
  )
Wait for all [P] Tasks to complete
Run @integration-coordinator validation
If INTEGRATED: proceed to [S] tasks or next phase
If CONFLICTS: report and await resolution
```

#### For Research During Planning
```
Identify knowledge gaps in plan.md
List specific research questions (be precise!)
For each question:
  Task(
    prompt: "You are @spec-researcher. Research: [specific question]
             Return findings in standard research template.
             Max 500 words. Include version numbers.",
    subagent_type: "spec-researcher"  
  )
Synthesize all research outputs into plan.md
```

#### For Codebase Exploration
```
For large codebase analysis, use built-in Explore agent:
  Task(
    prompt: "Explore [directory] for [pattern/concept].
             Return: file list, key patterns found, relevant code locations.",
    subagent_type: "Explore",
    thoroughness: "medium"  # quick | medium | very thorough
  )
```

#### For Validation After Implementation
```
After [P] batch completes:
  Task(
    prompt: "You are @integration-coordinator. 
             Validate integration of Tasks [ID list].
             Check: imports, types, API contracts, tests.
             Report using standard integration template.",
    subagent_type: "integration-coordinator"
  )
```

---

## Phase-Specific Parallel Rules

### Phase 1: Specify (`/speckit.specify`)

**Parallelization Level**: LOW

- Mostly sequential dialogue with user
- May spawn 1-2 research Tasks for domain clarification
- Focus on understanding requirements, not execution

```
Acceptable parallel operations:
- Research competing products
- Look up domain terminology
- Check existing codebase for similar features
```

### Phase 2: Plan (`/speckit.plan`)

**Parallelization Level**: MEDIUM-HIGH

This is where research parallelization shines.

```
Workflow:
1. Generate initial plan.md structure
2. Identify uncertain technical decisions
3. List specific research questions
4. Spawn N parallel @spec-researcher Tasks
5. Collect and synthesize findings
6. Update plan.md with research-backed decisions
7. Run @spec-validator on completed plan

Example research parallelization:
  Task("Research: Next.js 14 App Router caching strategies")
  Task("Research: Prisma vs Drizzle ORM performance comparison")  
  Task("Research: JWT refresh token rotation best practices")
  Task("Search codebase: existing authentication patterns")
  Task("Research: React Server Components data fetching patterns")
```

### Phase 3: Tasks (`/speckit.tasks`)

**Parallelization Level**: ANALYSIS ONLY

Task generation is inherently sequential, but analysis can parallelize.

```
Workflow:
1. Read plan.md thoroughly
2. If plan has multiple sections, spawn parallel analysis:
   Task("Analyze plan.md Section 2: Data Model - extract tasks")
   Task("Analyze plan.md Section 3: API Design - extract tasks")
   Task("Analyze plan.md Section 4: Frontend - extract tasks")
3. Synthesize into unified tasks.md
4. Apply [P] markers to parallelizable tasks
5. Validate task dependencies
```

### Phase 4: Implement (`/speckit.implement`)

**Parallelization Level**: MAXIMUM

This is where parallel execution provides the most value.

```
Workflow:
1. Parse tasks.md completely
2. Identify current phase (e.g., "Phase 2: Core Implementation")
3. Extract all [P]-marked tasks in phase
4. Spawn ALL [P] tasks simultaneously:
   Task(@task-implementer, "Task 2.1: UserService.ts")
   Task(@task-implementer, "Task 2.2: UserController.ts")
   Task(@task-implementer, "Task 2.3: User.types.ts")
   Task(@task-implementer, "Task 2.4: UserService.test.ts")
5. Wait for batch completion
6. Run @integration-coordinator
7. If TDD mode: run @test-validator before implementation tasks
8. Execute [S] sequential tasks one at a time
9. Repeat for next phase
```

---

## Context Optimization

### Prevent Context Window Pollution

Your main context is precious. Protect it.

```
# BAD: Loads entire files into main context
"Read all files in src/services/ and summarize their functionality"

# GOOD: Delegates to subagent, receives only summary
Task("Use Explore agent to scan src/services/ and return:
      - File list with descriptions
      - Key patterns and conventions
      - Dependency relationships")
```

### Token-Efficient Patterns

| Situation | Bad Pattern | Good Pattern |
|-----------|-------------|--------------|
| Reading multiple files | Sequential reads in main | Parallel Tasks, summarized returns |
| Large file analysis | Load full file | Use Grep for specific sections |
| Codebase exploration | Recursive file reads | Explore subagent with thoroughness setting |
| Research gathering | Single large search | Parallel focused searches |

### When to Keep in Main Context

✅ Keep in main context:
- Orchestration decisions
- User communication
- Final synthesis/summaries
- Small, quick operations (< 3 items)

❌ Delegate to Tasks:
- File reading/analysis
- Code implementation
- Research gathering
- Validation checks
- Any operation on > 3 independent items

---

## Conflict Prevention

### File Locking Convention

Parallel Tasks must not modify the same files. When spawning:

```
Task prompt should include:
"EXCLUSIVE FILES: [list of files this Task may modify]
 READ-ONLY FILES: [list of files for context only]
 If you need to modify a file not in EXCLUSIVE list, STOP and report."
```

### Safe Parallel Boundaries

| ✅ Safe to Parallelize | ❌ Never Parallelize |
|------------------------|---------------------|
| Different user stories | Same file modifications |
| Different file types (component/style/test/types) | Shared configuration files |
| Different modules/directories | Database migrations |
| Read-only operations | package.json modifications |
| Independent API endpoints | Global state changes |

### Conflict Detection Protocol

If a Task reports CONFLICT:
1. Identify which Tasks touched the same resource
2. Determine which Task's changes take precedence (usually later in dependency order)
3. Revert conflicting Task
4. Re-run with updated context
5. Or: escalate to user for decision

---

## Subagent Reference

### Project-Defined Subagents

Located in `.claude/agents/`:

| Agent | File | Trigger Phrases | Purpose |
|-------|------|-----------------|---------|
| `@spec-validator` | `spec-validator.md` | "validate spec", "check specification", "review requirements" | Specification quality validation |
| `@spec-researcher` | `spec-researcher.md` | "research [topic]", "investigate [question]" | Parallel technical research |
| `@task-implementer` | `task-implementer.md` | "implement task [ID]", "[P] execution" | Single task implementation |
| `@integration-coordinator` | `integration-coordinator.md` | "check integration", "verify batch", "validate phase" | Post-parallel validation |
| `@test-validator` | `test-validator.md` | "verify TDD", "check tests fail" | Test-first compliance |

### Built-in Subagents

| Agent | When Used | Purpose |
|-------|-----------|---------|
| `Explore` | Codebase scanning | File discovery, pattern search (read-only) |
| `Plan` | Plan mode research | Context gathering for planning |
| `general-purpose` | Complex multi-step tasks | When custom agent not defined |

### Invoking Subagents

```
# Automatic (Claude chooses based on description)
"Validate the specification for completeness"
→ Claude invokes @spec-validator

# Explicit (force specific agent)
"Use @spec-researcher to investigate JWT token rotation patterns"
→ Directly invokes spec-researcher

# Parallel spawn
"Spawn 5 @task-implementer agents for Tasks 2.1 through 2.5"
→ Parallel Task invocations
```

---

## Workflow Commands Quick Reference

### Spec Kit Commands
```
/speckit.specify   → Generate specification from description
/speckit.plan      → Create technical implementation plan
/speckit.analyze   → Cross-artifact consistency validation
/speckit.tasks     → Generate tasks.md with [P]/[S] markers
/speckit.implement → Execute tasks (MAXIMUM parallelization here)
```

### Parallel Execution Commands

When automatic detection doesn't trigger parallelization:

```
# Explicit parallel research
"Spawn parallel research Tasks for: [item1], [item2], [item3]"

# Explicit parallel implementation  
"Execute all [P] tasks in Phase 2 using 7 parallel agents"

# Explicit validation
"Run @integration-coordinator on completed Tasks 2.1-2.5"

# Explicit exploration
"Use Explore agent with 'very thorough' setting on src/services/"
```

---

## Error Recovery

### If Task Fails

```
1. Check Task output for error type:
   - Build error → Fix syntax/imports, re-run single Task
   - Test failure → Review test, may be expected (TDD)
   - File conflict → Resolve conflict, re-run affected Tasks
   - Dependency missing → Install dependency, re-run
   
2. If unclear:
   - Run @integration-coordinator for diagnosis
   - Check git status for unexpected changes
   - Review task dependencies in tasks.md
```

### If Context Depleted

```
1. Run /compact to summarize current state
2. Commit all completed work:
   git add -A && git commit -m "WIP: [phase] progress"
3. Start new session
4. Reference tasks.md for state recovery:
   "Continue implementation from Task [X.X] in [feature] tasks.md"
```

### If Parallel Batch Stalls

```
1. Check which Tasks are still running (UI indicator)
2. If Task appears stuck > 5 minutes:
   - May be waiting for user input (check prompt)
   - May have hit rate limit (wait and retry)
   - May have infinite loop (cancel and debug)
3. Cancel stuck Task, re-run with more specific prompt
```

---

## Performance Guidelines

### Token Cost Awareness

| Operation | Approximate Cost | Recommendation |
|-----------|------------------|----------------|
| Task spawn overhead | ~20k tokens | Group small related operations |
| Parallel batch (7 Tasks) | ~140k tokens | Worth it for 7+ independent operations |
| Main context file read | Variable | Delegate large files to Tasks |
| Subagent invocation | ~20k + work | Use for focused, substantial work |

### Parallelization Decision Matrix

| # of Independent Items | Action |
|------------------------|--------|
| 1-2 | Execute sequentially in main context |
| 3-5 | Consider parallelization (Task overhead may not be worth it) |
| 6+ | Definitely parallelize |
| 10+ | Parallelize in batches of 7-10 |

### Grouping Strategy

```
# BAD: Too granular (excessive overhead)
Task("Read file1.ts")
Task("Read file2.ts")
Task("Read file3.ts")
# 60k tokens overhead for 3 file reads

# GOOD: Grouped by purpose
Task("Read and summarize all service files in src/services/")
# 20k tokens overhead, same result
```

---

## Project-Specific Configuration

<!-- CUSTOMIZE THESE SECTIONS FOR YOUR PROJECT -->

### Tech Stack Details

```yaml
Language: TypeScript 5.x
Runtime: Node.js 20.x
Framework: [e.g., Next.js 14, Express, etc.]
Database: [e.g., PostgreSQL 15, MongoDB, etc.]
ORM: [e.g., Prisma, Drizzle, etc.]
Testing: [e.g., Jest, Vitest, pytest, etc.]
```

### Code Conventions

```yaml
Formatting: [e.g., Prettier, Black, etc.]
Linting: [e.g., ESLint, Ruff, etc.]
Naming: [e.g., camelCase for functions, PascalCase for components]
File structure: [e.g., feature-based, layer-based]
```

### Build Commands

```bash
# Development
npm run dev

# Build
npm run build

# Test
npm test
npm run test:integration

# Lint
npm run lint
npm run lint:fix

# Type check
npm run typecheck
```

### Environment Requirements

```bash
# Required environment variables
DATABASE_URL=
API_KEY=
# etc.

# Local setup
npm install
cp .env.example .env
npm run db:migrate
```

---

## Appendix: Example Parallel Execution Flow

### Scenario: Implementing User Authentication Feature

```
Human: /speckit.implement

Claude (Orchestrator):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 Reading tasks.md...

Phase 2: Core Implementation
├── [P] Task 2.1: Create User model (src/models/User.ts)
├── [P] Task 2.2: Create AuthService (src/services/AuthService.ts)
├── [P] Task 2.3: Create AuthController (src/controllers/AuthController.ts)
├── [P] Task 2.4: Create auth types (src/types/auth.ts)
├── [P] Task 2.5: Create AuthService.test.ts
├── [S] Task 2.6: Wire up auth routes (depends on 2.2, 2.3)
└── [S] Task 2.7: Add auth middleware (depends on 2.2)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🚀 Spawning 5 parallel Tasks for [P] items...

Task(@task-implementer) → Task 2.1: User model
Task(@task-implementer) → Task 2.2: AuthService
Task(@task-implementer) → Task 2.3: AuthController
Task(@task-implementer) → Task 2.4: auth types
Task(@task-implementer) → Task 2.5: AuthService.test.ts

⏳ Waiting for parallel batch...

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ All [P] Tasks completed

Task 2.1: COMPLETED - src/models/User.ts created
Task 2.2: COMPLETED - src/services/AuthService.ts created
Task 2.3: COMPLETED - src/controllers/AuthController.ts created
Task 2.4: COMPLETED - src/types/auth.ts created
Task 2.5: COMPLETED - src/services/AuthService.test.ts created (tests FAIL as expected)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔍 Running integration validation...

Task(@integration-coordinator) → Validate Phase 2 [P] batch

Integration Report:
- Import/Export: ✅ All resolved
- Type Compatibility: ✅ No errors
- Circular Dependencies: ✅ None detected
- Status: INTEGRATED

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
▶️ Proceeding to sequential tasks...

Executing Task 2.6: Wire up auth routes...
✅ Task 2.6 complete

Executing Task 2.7: Add auth middleware...
✅ Task 2.7 complete

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✨ Phase 2: Core Implementation COMPLETE

Ready for Phase 3? [Y/n]
```

---

*Last updated: [DATE]*
*Spec Kit version: v0.0.39+*
*Claude Code version: v2.1.x+*
