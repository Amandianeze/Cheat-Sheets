---
description: Launch parallel research tasks to investigate multiple technical questions simultaneously. Use when you need to gather information on several topics during planning or decision-making.
allowed-tools: Task, Read, Grep, Glob, WebSearch, WebFetch
---

# Parallel Research: $ARGUMENTS

You are orchestrating parallel research for the following question or topic list:

> **$ARGUMENTS**

## Instructions

Follow this workflow to maximize research efficiency through parallelization.

### Step 1: Parse the Research Request

Extract individual research questions from the input. If given a single topic, break it into specific researchable questions.

**Example Transformations:**

| Input | Extracted Questions |
|-------|---------------------|
| "Compare Prisma vs Drizzle" | 1. Prisma performance benchmarks 2. Drizzle performance benchmarks 3. Prisma TypeScript support 4. Drizzle TypeScript support 5. Migration handling comparison |
| "How should we handle auth?" | 1. JWT vs session authentication patterns 2. Refresh token best practices 3. OAuth2 implementation patterns 4. Existing codebase auth patterns |
| "Research React Server Components" | 1. RSC data fetching patterns 2. RSC caching strategies 3. RSC limitations and gotchas 4. RSC with our current stack |

### Step 2: Launch Parallel Research Agents

Spawn one `@spec-researcher` task per question. Launch ALL tasks in a single message to maximize parallelism.

```
Task(@spec-researcher, "Research Question 1: [specific question]")
Task(@spec-researcher, "Research Question 2: [specific question]")
Task(@spec-researcher, "Research Question 3: [specific question]")
...
```

**Guidelines for task prompts:**
- Be specific: "JWT refresh token rotation patterns" not "JWT stuff"
- Include context: "for a Next.js 14 application" if relevant
- Set scope: "focus on production-ready patterns, not tutorials"

### Step 3: Include Codebase Search

Always include at least one task that searches the existing codebase for related patterns:

```
Task(subagent_type: "Explore", 
     prompt: "Search codebase for existing [topic] implementations. 
              Look in src/ for patterns, conventions, and prior art.",
     thoroughness: "medium")
```

### Step 4: Wait for Completion

All research tasks run in parallel. Wait for all to complete before synthesizing.

### Step 5: Synthesize Findings

After all tasks complete, create a unified research document:

```markdown
# Research Summary: [Topic]

**Date**: [today]
**Questions Investigated**: [count]

## Key Findings

### [Topic Area 1]
[Synthesized findings from relevant tasks]

**Recommendation**: [specific guidance]

### [Topic Area 2]
[Synthesized findings from relevant tasks]

**Recommendation**: [specific guidance]

## Codebase Alignment
[How findings relate to existing codebase patterns]

## Decision Matrix

| Option | Pros | Cons | Fit for Project |
|--------|------|------|-----------------|
| [A] | | | HIGH/MEDIUM/LOW |
| [B] | | | HIGH/MEDIUM/LOW |

## Recommended Approach
[Final recommendation with rationale]

## Open Questions
- [Questions that need human input]
- [Questions requiring further research]
```

### Step 6: Save Research Document

If researching for a Spec Kit feature, save to:
```
.specify/specs/[feature]/research.md
```

Otherwise, save to:
```
docs/research/[date]-[topic-slug].md
```

Create the directory if it doesn't exist:
```bash
mkdir -p docs/research
```

## Example Execution

**Input**: `/research Compare state management: Redux Toolkit vs Zustand vs Jotai`

**Step 1 Output**:
```
Extracted 6 research questions:
1. Redux Toolkit bundle size and performance
2. Zustand bundle size and performance  
3. Jotai bundle size and performance
4. Redux Toolkit developer experience and TypeScript support
5. Zustand/Jotai developer experience comparison
6. Existing state patterns in our codebase
```

**Step 2 Actions**:
```
Spawning 6 parallel research tasks...
Task(@spec-researcher) → Redux Toolkit performance analysis
Task(@spec-researcher) → Zustand performance analysis
Task(@spec-researcher) → Jotai performance analysis
Task(@spec-researcher) → Redux Toolkit DX and TypeScript
Task(@spec-researcher) → Zustand vs Jotai DX comparison
Task(Explore) → Search codebase for state management patterns
```

**Step 5 Output**:
```
# Research Summary: State Management Comparison

**Date**: 2025-01-26
**Questions Investigated**: 6

## Key Findings
...
```

## Notes

- Maximum 10 parallel tasks (Claude Code limit)
- Each task has ~20k token overhead
- For > 10 questions, batch into groups
- Research tasks use `@spec-researcher` agent from `.claude/agents/`
- Codebase search uses built-in `Explore` agent
